<script>
    $(function() {
        $elem = $('#search_customer_rank');
        $('#searchDetail').prepend($elem.html());
        $elem.remove();
    });
</script>