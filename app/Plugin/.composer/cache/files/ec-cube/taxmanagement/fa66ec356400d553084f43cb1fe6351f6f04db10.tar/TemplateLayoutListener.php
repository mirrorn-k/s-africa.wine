<?php

namespace Plugin\TaxManagement;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Twig\Environment;
use Plugin\TaxManagement\Services\Simple_html_dom;
use Exception;
use Plugin\TaxManagement\Services\simple_html_dom_node;

/**
 * Class TemplateLayoutListener
 * @package Plugin\TaxManagement
 */
class TemplateLayoutListener implements EventSubscriberInterface
{

    /**
     * @var Environment
     */
    protected $twig;

    const TAX_MANAGEMENT_COMMENT_REGEX = '/(<!-- tax_management_通常価格 -->)[\s\S]+?(<!-- tax_management_商品コード -->)/s';
    const TAX_MANAGEMENT_SALE_PRICE_CLASSNAME = 'tax_management-sale_price';
    const TAX_MANAGEMENT_LIST_PRICE_CLASSNAME = 'tax_management-list_price';
    const TAX_MANAGEMENT_DISCOUNT_RATE_CLASSNAME = 'tax_management-discount_rate';
    const TAX_MANAGEMENT_CHECK_CLASSNAME = 'tax_management-check';
    const TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME = 'tax_management-detail_page';
    const TAX_MANAGEMENT_LIST_PAGE_CLASSNAME = 'tax_management-list_page';

    const DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_PARENT_CLASSNAME = 'ec-productRole__price > .ec-price';
    const DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_PRICE_CLASSNAME = 'ec-price__price';
    const DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_TAX_CLASSNAME = 'ec-price__tax';
    const DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PARENT_CLASSNAME = 'ec-productRole__priceRegular';
    const DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PRICE_CLASSNAME = 'ec-productRole__priceRegularPrice';
    const DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PRICE_WITH_CLASS_CLASSNAME = 'price01-default';
    const DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_TAX_CLASSNAME = 'ec-productRole__priceRegularTax';

    const LIST_PAGE_SALE_PRICE_DEFAULT_TAG_PARENT_CLASSNAME = 'price02-default';

    const CSS_URL = '/../../plugin/TaxManagement3/assets/css/demo.css';

    /**
     * TemplateLayoutListener constructor.
     * @param Environment $twig
     */
    public function __construct(
        Environment $twig
    ) {
        $this->twig = $twig;
    }

    public function onKernelResponse(FilterResponseEvent $event)
    {
        if (!$event->isMasterRequest()) {
            return;
        }

        /** @var \Symfony\Component\HttpFoundation\ParameterBag $attributes */
        $request = $event->getRequest();
        $attributes = $request->attributes;
        $route = $attributes->get('_route');
        $TaxManagementConfig = $request->get('TaxManagementConfig');

        if (is_null($TaxManagementConfig)) {
            log_error('Can’t get TaxManagement config from database plg_tax_management_config table');
            return;
        }
        else{
            $entityName = get_class($TaxManagementConfig);
            if ($entityName != 'Plugin\TaxManagement42\Entity\Config') {
                log_error('Can’t get TaxManagement config from database plg_tax_management_config table');
                return;
            }
        }

        $response = $event->getResponse();

        $data = '';
        if ($response instanceof Response) {
            $data = $response->getContent();
        }
        if ($route == "product_detail") {
            $Product = $request->get('Product');
            $price01 = '';
            $price02 = '';
            if ($response instanceof Response && $Product) {
                $doc = new Simple_html_dom($data, null, null, null, false);
                // get custom tag sale price
                $price01customElements = $doc->find('.'.self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME);
                $price02customElements = $doc->find('.'.self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME);
                $isCommentTagExist = preg_match(self::TAX_MANAGEMENT_COMMENT_REGEX, $data);
                
                $isTaxListPriceTagExist = count($price01customElements) > 0 ;
                $isTaxSalePriceTagExist = count($price02customElements) > 0 ;

                if($isCommentTagExist && !$isTaxListPriceTagExist && !$isTaxSalePriceTagExist) {
                    try {
                        $template_price01 = $this->twig->loadTemplate('@TaxManagement/default/Product/detail_list_price.twig');
                        $price01 = $template_price01->render(array('Product' => $Product, 'isCommentTagExist' => $isCommentTagExist));
                        $template_price02 = $this->twig->loadTemplate('@TaxManagement/default/Product/detail_sale_price.twig');
                        $price02 = $template_price02->render(array('Product' => $Product, 'TaxManagementConfig' => $TaxManagementConfig, 'isCommentTagExist' => $isCommentTagExist, 'isIncludeDiscountRate' => $TaxManagementConfig->isDiscountRateFlag()));
                        
                        $data = preg_replace(self::TAX_MANAGEMENT_COMMENT_REGEX, $price01. $price02, $data, 1);
                    } catch (Exception $e) {
                    }
                } else {
                    try{
                        $price02Value = $this->_getPriceValue($Product); // price02 values with number_format
                        $price01Price = $this->_getPriceValue($Product, 1); // price01 values with number_format
                        $price02NoTaxClass = $this->_getPrice02AdditionalClass($TaxManagementConfig); // additional class in case default tag
                        $price02IncTaxClass = $this->_getPrice02AdditionalClass($TaxManagementConfig, 1); // additional class in case default tag

                        $price01IncTax = $this->_getPrice01IncludeTaxText($TaxManagementConfig, $Product);
                        $price02NoTax = $this->_getPrice02NoTaxText($TaxManagementConfig, $Product);
                        $price02IncTax = $this->_getPrice02IncludeTaxText($TaxManagementConfig, $Product);

                        // custom tag process
                        $template_price01 = $this->twig->loadTemplate('@TaxManagement/default/Product/detail_list_price.twig');
                        if ($isTaxListPriceTagExist) {
                            foreach($price01customElements as $price01custom) {
                                if(!$this->_hasClass(self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME, $price01custom)) {
                                    $price01custom->setAttribute('class', $price01custom->getAttribute('class'). ' ' . self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME);
                                }
                                
                                $price01 = $template_price01->render(array('Product' => $Product, 'isCommentTagExist' => $isCommentTagExist));

                                $price01custom->innertext = $price01;
                                $defaultPriceValueElement = $price01custom->find('.' . self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PRICE_CLASSNAME);
                                $defaultPriceTaxElement = $price01custom->find('.' . self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_TAX_CLASSNAME);
                                $this->_addCheckClassToDefaultElement($defaultPriceValueElement);
                                $this->_addCheckClassToDefaultElement($defaultPriceTaxElement);
                            }
                        }
                    } catch (\Throwable $th) {
                        log_error($th);
                    }
                    // default tag process
                    if ($Product->hasProductClass()) {
                        try{
                            $price01DefaultElements = $doc->find('.' . self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PARENT_CLASSNAME);
                            if(count($price01DefaultElements)) {
                                foreach($price01DefaultElements as $price01Default) {
                                    
                                    if(count($price01Default->find('.'.self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME)) > 0 || 
                                    $this->_hasClass(self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME, $price01Default)) {
                                        continue;
                                    }
                                    
                                    $price01Value = $price01Default->find('.' . self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PRICE_CLASSNAME);
                                    if(
                                        !$price01Value||
                                        count($price01Value) > 1 ||
                                        $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price01Value[0])) {
                                        continue;
                                    }
                                    

                                    $price01ValueElement = $price01Value[0]->find('.' . self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PRICE_WITH_CLASS_CLASSNAME);
                                    if(
                                        !$price01ValueElement||
                                        count($price01ValueElement) > 1 ||
                                        $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price01ValueElement[0])) {
                                        continue;
                                    }

                                    $price01ValueElement = $price01ValueElement[0];
                                    $price01Tax = $price01Value[0]->next_sibling();
                                    if(
                                        !$price01Tax || 
                                        !$this->_hasClass(self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_TAX_CLASSNAME, $price01Tax) || 
                                        $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price01Tax)) {
                                        continue;
                                    }
                                    $price01ValueElement->innertext = $price01IncTax;
                                    $price01Tax->innertext = '税込';
                                    $price01Default->setAttribute('class', $price01Default->getAttribute('class'). ' '. self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME . ' ' . self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME);
                                }
                            }
                        } catch (\Throwable $th) {
                            log_error($th);
                        }
                    } else {
                        try{
                            $price01Value = $doc->find('.' . self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_PRICE_CLASSNAME);
                            if(count($price01Value)) {
                                foreach($price01Value as $price01ValueElement) {
                                    if(
                                        count($price01ValueElement->find('.'.self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME)) > 0 || 
                                        $this->_hasClass(self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME, $price01ValueElement) || 
                                        $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price01ValueElement)) {
                                        continue;
                                    }

                                    $price01TaxElement = $price01ValueElement->next_sibling();
                                    if(
                                        !$price01TaxElement || 
                                        !$this->_hasClass(self::DETAIL_PAGE_LIST_PRICE_DEFAULT_TAG_TAX_CLASSNAME, $price01TaxElement)) {
                                        continue;
                                    }
                                    if(
                                        count($price01TaxElement->find('.'.self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME)) > 0 || 
                                        $this->_hasClass(self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME, $price01TaxElement) ||
                                        $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price01TaxElement)) {
                                        continue;
                                    }

                                    $price01ValueElement->innertext = '通常価格：' . $price01IncTax;
                                    $price01TaxElement->innertext = '税込';
                                    $price01ValueElement->setAttribute('class', $price01ValueElement->getAttribute('class'). ' '. self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME . ' ' . self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME);
                                    $price01TaxElement->setAttribute('class', $price01TaxElement->getAttribute('class'). ' '. self::TAX_MANAGEMENT_LIST_PRICE_CLASSNAME . ' ' . self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME);
                                }
                            }
                        } catch (\Throwable $th) {
                            log_error($th);
                        }
                    }

                    try{
                        $checkClassElements = $doc->find('.'.self::TAX_MANAGEMENT_CHECK_CLASSNAME);
                        if($checkClassElements) {
                            foreach($checkClassElements as $checkClassElement) {
                                $this->_removeClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $checkClassElement);
                            }
                        }
                    } catch (\Throwable $th) {
                        log_error($th);
                    }

                    $data = $doc->save();
                    $doc->clear();
                    unset($doc);
                    $doc = new Simple_html_dom($data, null, null, null, false);
                    try{
                        $price02customElements = $doc->find('.'.self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME);
                        $isTaxSalePriceTagExist = count($price02customElements) > 0 ;

                        $template_price02 = $this->twig->loadTemplate('@TaxManagement/default/Product/detail_sale_price.twig');
                        if ($isTaxSalePriceTagExist) {
                            foreach($price02customElements as $price02custom) {
                                if(!$this->_hasClass(self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME, $price02custom)) {
                                    $price02custom->setAttribute('class', $price02custom->getAttribute('class'). ' ' . self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME);
                                }

                                $price02 = $template_price02->render(array('Product' => $Product, 'TaxManagementConfig' => $TaxManagementConfig, 'isCommentTagExist' => false, 'isIncludeDiscountRate' => true));
                                $price02custom->innertext = $price02;
                                $defaultPriceValueElement = $price02custom->find('.' . self::DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_PRICE_CLASSNAME);
                                $defaultPriceTaxElement = $price02custom->find('.' . self::DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_TAX_CLASSNAME);
                                $this->_addCheckClassToDefaultElement($defaultPriceValueElement);
                                $this->_addCheckClassToDefaultElement($defaultPriceTaxElement);
                            }
                        }
                    } catch (\Throwable $th) {
                        log_error($th);
                    }

                    try{
                        $price02DefaultElements = $doc->find('.'.self::DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_PARENT_CLASSNAME);
                        if(count($price02DefaultElements)) {
                            foreach($price02DefaultElements as $price02Default) {
                                if(count($price02Default->find('.'.self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME)) > 0 || 
                                $this->_hasClass(self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME, $price02Default)) {
                                    continue;
                                }

                                $price02ValueElement = $price02Default->find('.'. self::DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_PRICE_CLASSNAME);
                                if(
                                    !$price02ValueElement||
                                    count($price02ValueElement) > 1 ||
                                    $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price02ValueElement[0])) 
                                {
                                    continue;
                                }

                                $price02ValueElement = $price02ValueElement[0];
                                $price02TaxElement = $price02ValueElement->next_sibling();
                                if(
                                    !$price02TaxElement || 
                                    !$this->_hasClass(self::DETAIL_PAGE_SALE_PRICE_DEFAULT_TAG_TAX_CLASSNAME, $price02TaxElement) || 
                                    $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price02TaxElement)) 
                                {
                                    continue;
                                }
                                if($price02ValueElement && $price02TaxElement) {
                                    foreach(explode(' ', $price02NoTaxClass) as $className) {
                                        if(!$this->_hasClass($className, $price02ValueElement)) {
                                            $price02ValueElement->setAttribute('class', $price02ValueElement->getAttribute('class'). ' '. $className);
                                        }
                                    }
                                    foreach(explode(' ', $price02IncTaxClass) as $className) {
                                        if(!$this->_hasClass($className, $price02TaxElement)) {
                                            $price02TaxElement->setAttribute('class', $price02TaxElement->getAttribute('class'). ' '. $className);
                                        }
                                    }

                                    $discount_rate = '';
                                    try {
                                        $template_discount_rate = $this->twig->loadTemplate('@TaxManagement/default/Product/detail_discount_rate.twig');
                                        $discount_rate = $template_discount_rate->render(array('Product' => $Product, 'TaxManagementConfig' => $TaxManagementConfig));
                                    } catch (Exception $e) {

                                    }
                                    try{
                                        if ($TaxManagementConfig->isIncludeTaxFlag() === false) {
                                            $price02ValueElement->innertext = $price02NoTax;
                                            $price02TaxElement->innertext = '('. $price02IncTax . '税込)';
                                            $price02TaxElement->outertext .= $discount_rate;
                                        } else {
                                            $price02ValueElement->innertext = $price02IncTax;
                                            $price02TaxElement->innertext = '税込';
                                            $price02TaxElement->outertext .= $discount_rate;
                                        }
                                    } catch (\Throwable $th) {
                                        log_error($th);
                                    }
                                    $price02Default->setAttribute('class', $price02Default->getAttribute('class'). ' '. self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME . ' ' . self::TAX_MANAGEMENT_DETAIL_PAGE_CLASSNAME);
                                }
                            }
                        }
                    } catch (\Throwable $th) {
                        log_error($th);
                    }

                    try{
                        // remove check class
                        $checkClassElements = $doc->find('.'.self::TAX_MANAGEMENT_CHECK_CLASSNAME);
                        if($checkClassElements) {
                            foreach($checkClassElements as $checkClassElement) {
                                $this->_removeClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $checkClassElement);
                            }
                        }
                    } catch (\Throwable $th) {
                        log_error($th);
                    }

                    $data = $doc->save();
                    $doc->clear();
                    unset($doc);
                }
                
                $response->setContent($data);
                $event->setResponse($response);

            }
        } else if ($route == "product_list") {
            $Products = $request->get('tax_management_products');
            $indexArr = [];

            $price01 = '';
            $price02 = '';
            if ($response instanceof Response && $Products) {
                foreach($Products as $key => $Product) {
                    $indexArr[$Product->getId()] = $key;
                }

                $doc = new Simple_html_dom($data, null, null, null, false);

                try{
                    $price02customElements = $doc->find('.'.self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME);
                    if (count($price02customElements)) {
                        foreach($price02customElements as $price02custom) {
                            // get product id
                            $classes = explode(' ', $price02custom->getAttribute('class'));
                            
                            $product_id = 0;
                            foreach($classes as $class) {
                                if(preg_match("/^tax_management_id_([1-9][0-9]*)$/i", $class, $matches)) {
                                    $product_id = $matches[1];
                                    break;
                                }
                            }
                            if(!$product_id) {
                                continue;
                            }

                            if(!isset($indexArr[$product_id])) {
                                continue;
                            }

                            $index = $indexArr[$product_id];
                            $Product = $Products[$index];
                            $price02Value = $this->_getPriceValue($Product);
                            $price02IncTax = $this->_getPrice02IncludeTaxText($TaxManagementConfig, $Product);

                            $defaultPriceValueElement = $price02custom->find('.' . self::LIST_PAGE_SALE_PRICE_DEFAULT_TAG_PARENT_CLASSNAME);
                            $this->_addCheckClassToDefaultElement($defaultPriceValueElement);

                            $price02 = '';
                            try {
                                $template_price02 = $this->twig->loadTemplate('@TaxManagement/default/Product/list_sale_price.twig');
                                $price02 = $template_price02->render(array('Product' => $Product, 'TaxManagementConfig' => $TaxManagementConfig, 'isIncludeDiscountRate' => false));
                            } catch(Exception $e) {

                            }
                            if(!$this->_hasClass(self::TAX_MANAGEMENT_LIST_PAGE_CLASSNAME, $price02custom)) {
                                $price02custom->setAttribute('class', $price02custom->getAttribute('class'). ' ' . self::TAX_MANAGEMENT_LIST_PAGE_CLASSNAME);
                            }

                            if($price02) {
                                $discount_rate = '';
                                try {
                                    $template_discount_rate = $this->twig->loadTemplate('@TaxManagement/default/Product/list_discount_rate.twig');
                                    $discount_rate = $template_discount_rate->render(array('Product' => $Product, 'TaxManagementConfig' => $TaxManagementConfig));
                                } catch(Exception $e) {

                                }
                                $price02custom->innertext = $price02;
                                $price02custom->outertext .= $discount_rate;
                            }
                        }
                    }
                } catch (\Throwable $th) {
                    log_error($th);
                }

                try{
                    $price02DefaultElements = $doc->find('.'.self::LIST_PAGE_SALE_PRICE_DEFAULT_TAG_PARENT_CLASSNAME);
                    if(count($price02DefaultElements)) {
                        foreach($price02DefaultElements as $price02Default) {
                            if(
                                count($price02Default->find('.'.self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME)) > 0 || 
                                $this->_hasClass(self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME, $price02Default) ||
                                $this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $price02Default)) {
                                continue;
                            }
                            $classes = explode(' ', $price02Default->getAttribute('class'));
                            
                            $product_id = 0;
                            foreach($classes as $class) {
                                if(preg_match("/^tax_management_id_([1-9][0-9]*)$/i", $class, $matches)) {
                                    $product_id = $matches[1];
                                    break;
                                }
                            }
                            if(!$product_id) {
                                continue;
                            }

                            if(!isset($indexArr[$product_id])) {
                                continue;
                            }

                            $index = $indexArr[$product_id];
                            $Product = $Products[$index];
                            $price02Value = $this->_getPriceValue($Product);
                            $price02NoTax = $this->_getPrice02NoTaxText($TaxManagementConfig, $Product);
                            $price02IncTax = $this->_getPrice02IncludeTaxText($TaxManagementConfig, $Product);

                            $discount_rate = '';
                            try {
                                $template_discount_rate = $this->twig->loadTemplate('@TaxManagement/default/Product/list_discount_rate.twig');
                                $discount_rate = $template_discount_rate->render(array('Product' => $Product, 'TaxManagementConfig' => $TaxManagementConfig));
                            } catch(Exception $e) {

                            }
                            
                            if ($TaxManagementConfig->isIncludeTaxFlag() === false) {
                                $price02Default->innertext = $price02NoTax;
                            } else {
                                $price02Default->innertext = $price02IncTax;
                            }
                            $price02Default->setAttribute('class', $price02Default->getAttribute('class'). ' '. self::TAX_MANAGEMENT_SALE_PRICE_CLASSNAME . ' ' . self::TAX_MANAGEMENT_LIST_PAGE_CLASSNAME);
                            if($discount_rate) {
                                $price02Default->outertext .= $discount_rate;
                            }
                        }
                    }
                } catch (\Throwable $th) {
                    log_error($th);
                }

                try{
                    // remove check class
                    $checkClassElements = $doc->find('.'.self::TAX_MANAGEMENT_CHECK_CLASSNAME);
                    if($checkClassElements) {
                        foreach($checkClassElements as &$checkClassElement) {
                            $this->_removeClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $checkClassElement);
                        }
                    }
                } catch (\Throwable $th) {
                    log_error($th);
                }

                $data = $doc->save();
                $doc->clear();
                unset($doc);
                
                $response->setContent($data);
                $event->setResponse($response);
            }
        }
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return [
            KernelEvents::RESPONSE => ['onKernelResponse', 1],
        ];
    }

    private function _hasClass($className, $node)
    {
        if(!$node instanceof simple_html_dom_node) {
            return false;
        }

        $classes = explode(' ', $node->getAttribute('class'));

        if(!$className) {
            return false;
        }

        return in_array($className, $classes);
    }

    private function _removeClass($className, &$node)
    {
        if(!$node instanceof simple_html_dom_node) {
            return false;
        }

        $classes = explode(' ', $node->getAttribute('class'));

        if(!$className) {
            return false;
        }

        foreach($classes as $key => $class) {
            if($className == $class) {
                unset($classes[$key]);
                $classesText = implode(' ', $classes);
                $node->setAttribute('class', $classesText);
            }
        }

    }

    private function _getPrice01IncludeTaxText($TaxManagementConfig, $Product) {
        $price01Value = $this->_getPriceValue($Product, 1, false);
        $price01IncTax = '';
        if($price01Value['price01IncTaxMin'] === null) {
            return '';
        }
        if ($Product->hasProductClass()) {
            if ($Product->getPrice01Min() == $Product->getPrice01Max()) {
                $price01IncTax = $price01Value['price01IncTaxMin'];
            } else {
                $price01IncTax = $price01Value['price01IncTaxMin'] . ' ～ ' . $price01Value['price01IncTaxMax'];
            }
        } else {
            $price01IncTax = $price01Value['price01IncTaxMin'];
        }

        return $price01IncTax;
    }

    private function _getPrice02IncludeTaxText($TaxManagementConfig, $Product) {
        $price02Value = $this->_getPriceValue($Product, 2, false);
        $price02IncTax = '';
        if ($Product->hasProductClass()) {
            if ($Product->getPrice02Min() == $Product->getPrice02Max()) {
                $price02IncTax = $price02Value['price02IncTaxMin'];
            } else {
                $price02IncTax = $price02Value['price02IncTaxMin'] . ' ～ ' . $price02Value['price02IncTaxMax'];
            }
        } else {
            $price02IncTax = $price02Value['price02IncTaxMin'];
        }

        return $price02IncTax;
    }

    private function _getPrice02NoTaxText($TaxManagementConfig, $Product) {
        $price02Value = $this->_getPriceValue($Product, 2, false);
        $price02NoTax = '';
        if ($Product->hasProductClass()) {
            if ($Product->getPrice02Min() == $Product->getPrice02Max()) {
                $price02NoTax = $price02Value['price02NoTaxMin'];
            } else {
                $price02NoTax = $price02Value['price02NoTaxMin'] . ' ～ ' . $price02Value['price02NoTaxMax'];
            }
        } else {
            $price02NoTax = $price02Value['price02NoTaxMin'];
        }
        return $price02NoTax;
    }

    private function _getPrice02AdditionalClass($TaxManagementConfig, $type = 0) {
        if ($TaxManagementConfig->isIncludeTaxFlag() === false) {
            $price02NoTaxClass = 'price02-default price02-default-no-tax';
            $price02IncTaxClass = '';
        } else {
            $price02NoTaxClass = 'price02-default';
            $price02IncTaxClass = '';
        }

        if($type == 0) {
            return $price02NoTaxClass;
        } 
        if($type == 1) {
            return $price02IncTaxClass;
        }
    }

    /**
     * Calculate prices value of $Product based on $kind includes
     *
     * @param Eccube\Entity\Product $Product
     * @param int $kind default 2: price02 or sale price
     *                          1: price01 or list price
     * @return array(
     *      'price{$kind}NoTaxMin' => price base on kind not including tax 
     *      'price{$kind}NoTaxMax' =>
     *      'price{$kind}IncTaxMin'
     *      'price{$kind}IncTaxMax'
     *  )
     * 
     */
    private function _getPriceValue($Product, $kind = 2, $number_format = true) {
        if($kind == 2) {
            if($number_format) {
                return array(
                    'price02NoTaxMin' => number_format($Product->getPrice02Min()),
                    'price02NoTaxMax' => number_format($Product->getPrice02Max()),
                    'price02IncTaxMin' => number_format($Product->getPrice02IncTaxMin()),
                    'price02IncTaxMax' => number_format($Product->getPrice02IncTaxMax()),
                );
            }
            return array(
                'price02NoTaxMin' => $this->_convertPriceToString($Product->getPrice02Min()),
                'price02NoTaxMax' => $this->_convertPriceToString($Product->getPrice02Max()),
                'price02IncTaxMin' => $this->_convertPriceToString($Product->getPrice02IncTaxMin()),
                'price02IncTaxMax' => $this->_convertPriceToString($Product->getPrice02IncTaxMax()),
            );
        }
        if($kind == 1) {
            if($number_format) {
                return array(
                    'price01NoTaxMin' => $Product->getPrice01Min() !== null ? number_format($Product->getPrice01Min()): null,
                    'price01NoTaxMax' => $Product->getPrice01Min() !== null ? number_format($Product->getPrice01Max()): null,
                    'price01IncTaxMin' => $Product->getPrice01Min() !== null ? number_format($Product->getPrice01IncTaxMin()): null,
                    'price01IncTaxMax' => $Product->getPrice01Min() !== null ? number_format($Product->getPrice01IncTaxMax()): null,
                );
            }
            return array(
                'price01NoTaxMin' => $Product->getPrice01Min() !== null ? $this->_convertPriceToString($Product->getPrice01Min()): null,
                'price01NoTaxMax' => $Product->getPrice01Min() !== null ? $this->_convertPriceToString($Product->getPrice01Max()): null,
                'price01IncTaxMin' => $Product->getPrice01Min() !== null ? $this->_convertPriceToString($Product->getPrice01IncTaxMin()): null,
                'price01IncTaxMax' => $Product->getPrice01Min() !== null ? $this->_convertPriceToString($Product->getPrice01IncTaxMax()): null,
            );
        }
    }

    private function _addCheckClassToDefaultElement(&$elements) {
        if(count($elements) != 0) {
            foreach($elements as $element) {
                if(!$this->_hasClass(self::TAX_MANAGEMENT_CHECK_CLASSNAME, $element)) {
                    $element->setAttribute('class', $element->getAttribute('class'). ' ' . self::TAX_MANAGEMENT_CHECK_CLASSNAME);
                } 
            } 
        }
    }

    private function _convertPriceToString($price)
    {
        if (!(int)$price) {
            return '';
        }
        $priceValueTemplate = $this->twig->loadTemplate('@TaxManagement/default/Product/sale_price_value.twig');
        $result = $priceValueTemplate->render(array('price' => $price));
        return $result;
    }
}
