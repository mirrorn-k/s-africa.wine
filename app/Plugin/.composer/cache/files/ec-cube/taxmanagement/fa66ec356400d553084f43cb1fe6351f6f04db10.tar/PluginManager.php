<?php

namespace Plugin\TaxManagement;

use Eccube\Plugin\AbstractPluginManager;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Plugin\TaxManagement\Entity\Config;

class PluginManager extends AbstractPluginManager
{
    public function install(array $meta, ContainerInterface $container)
    {
	}

    public function enable(array $meta, ContainerInterface $container)
    {
        $this->initConfigData($container);
	}

    public function disable(array $meta, ContainerInterface $container)
    {

	}

    public function update(array $meta, ContainerInterface $container)
    {
        $this->initConfigData($container);
    }

    public function uninstall(array $meta, ContainerInterface $container)
    {
    }

    private function initConfigData(ContainerInterface $container)
    {
        $entityManager = $container->get('doctrine.orm.entity_manager');
        $configRepository = $entityManager->getRepository(Config::class);
        $Config = $configRepository->get();
        if ($Config === null)
        {
            $Config = new Config();
            $Config->setIncludeTaxFlag(false);
            $Config->setDiscountRateFlag(true);
            $Config->setDisplayDiscountType(0);

            $entityManager->persist($Config);
            $entityManager->flush($Config);
        }
    }
}

?>