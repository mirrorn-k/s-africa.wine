<?php

namespace Plugin\TaxManagement\Form\Type\Admin;

use Plugin\TaxManagement\Entity\Config;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;


class ConfigType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('discount_rate_flag', ChoiceType::class, [
                'label' => '割引率表示',
                'required' => true,
                'choices'  => [
                    '非表示' => false,
                    '表示' => true,
                ],
                'expanded' => true,
            ])
            ->add('include_tax_flag', ChoiceType::class, [
                'label' => '税表示',
                'required' => true,
                'choices'  => [
                    '税抜き' => false,
                    '税込み' => true,
                ],
                'expanded' => true,
            ])
            ->add('display_discount_type', ChoiceType::class, [
                'label' => '割引率の小数点',
                'choices'  => [
                    '切り上げ' => 0,  // 0: round up for discount value
                    '四捨五入' => 2, // 2: display decimal value with round for discount value
                    '切り捨て' => 1,  // 1: round down for discount value
                ],
                'expanded' => true,
            ]);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Config::class,
        ]);
    }
}
